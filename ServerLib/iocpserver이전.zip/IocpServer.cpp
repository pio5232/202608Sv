#include "LibraryPch.h"
#include <MSWSock.h>
#include <Windows.h>
#include <conio.h>
#include "NetworkBase.h"

/*-----------------------
	  IocpServer
-----------------------*/

jh::IocpServer::IocpServer(const WCHAR* serverName) : m_config{}, m_hCompletionPort(nullptr), m_listenSock(INVALID_SOCKET), m_pcwszServerName(serverName), m_pSessionArray(nullptr),
m_workerExecutor{}, m_activeSessionManager{}
{
	m_pJobQueue = jh::MakeShared<JobQueue>();

	m_lSessionCount = 0;
	m_llTotalAcceptedSessionCount = 0;

	m_llDisconnectedCount = 0;
	m_llTotalDisconnectCount = 0;

	m_lSendCount = 0;
	m_lRecvCount = 0;

}

jh::IocpServer::~IocpServer()
{
	if (nullptr != m_pSessionArray)
	{
		delete[] m_pSessionArray;
		m_pSessionArray = nullptr;
	}
}

bool jh::IocpServer::Start()
{
	if (0 == m_config.m_dwConcurrentWorkerThreadCount)
	{
		SYSTEM_INFO sys;
		GetSystemInfo(&sys);

		m_config.m_dwConcurrentWorkerThreadCount = sys.dwNumberOfProcessors;
	}

	_LOG(m_pcwszServerName, LOG_LEVEL_INFO, L"[Start] Concurrent ThreadCount : [%u]", m_config.m_dwConcurrentWorkerThreadCount);

	m_hCompletionPort = CreateIoCompletionPort(INVALID_HANDLE_VALUE, 0, 0, m_config.m_dwConcurrentWorkerThreadCount);

	if (NULL == m_hCompletionPort)
	{
		_LOG(m_pcwszServerName, LOG_LEVEL_SYSTEM, L"[Start] IOCP Handle is Null");

		return false;
	}

	m_listenSock = socket(AF_INET, SOCK_STREAM, 0);
	if (INVALID_SOCKET == m_listenSock)
	{
		_LOG(m_pcwszServerName, LOG_LEVEL_SYSTEM, L"[Start] ListenSocket is Invalid");

		return false;
	}

	int sndBuffSize = 0;
	DWORD zeroCpyRet = setsockopt(m_listenSock, SOL_SOCKET, SO_SNDBUF, (char*)&sndBuffSize, sizeof(sndBuffSize));
	if (SOCKET_ERROR == zeroCpyRet)
	{
		int gle = WSAGetLastError();
		_LOG(m_pcwszServerName, LOG_LEVEL_SYSTEM, L"[Start] Set ZeroCpy Failed. GetLastError : [%d]", gle);

		return false;

	}
	DWORD setLingerRet = setsockopt(m_listenSock, SOL_SOCKET, SO_LINGER, (char*)&m_config.m_lingerOption, sizeof(linger));
	if (SOCKET_ERROR == setLingerRet)
	{
		int gle = WSAGetLastError();
		_LOG(m_pcwszServerName, LOG_LEVEL_SYSTEM, L"[Start] Set Linger Failed. GetLastError : [%d]", gle);

		return false;
	}

	char nodelay = 1;
	DWORD nodelayRet = setsockopt(m_listenSock, IPPROTO_TCP, TCP_NODELAY, &nodelay, sizeof(nodelay));
	if (SOCKET_ERROR == nodelay)
	{
		int gle = WSAGetLastError();
		_LOG(m_pcwszServerName, LOG_LEVEL_SYSTEM, L"[Start] Set NoDelay Failed. GetLastError : [%d]", gle);

		return false;
	}

	SOCKADDR_IN sockaddrIn{ AF_INET, htons(m_config.m_usPort), NetAddress::IpToAddr(m_config.m_wszIp) };

	DWORD bindRet = bind(m_listenSock, (SOCKADDR*)&sockaddrIn, sizeof(SOCKADDR_IN));

	if (SOCKET_ERROR == bindRet)
	{
		int gle = WSAGetLastError();

		_LOG(m_pcwszServerName, LOG_LEVEL_SYSTEM, L"[Start] Bind Failed. GetLastError :[%d]", gle);

		return false;
	}

	DWORD listenRet = listen(m_listenSock, SOMAXCONN);
	if (SOCKET_ERROR == listenRet)
	{
		int gle = WSAGetLastError();

		_LOG(m_pcwszServerName, LOG_LEVEL_SYSTEM, L"[Listen] - Listen Failed. GetLastError : %u", gle);

		return false;
	}

	InitializeServerTasks();

	OnStart();

	return true;
}


void jh::IocpServer::Stop()
{
	closesocket(m_listenSock);
	m_listenSock = INVALID_SOCKET;

	OnStop();

	for (int i = 0; i < m_config.m_dwConcurrentWorkerThreadCount; i++)
	{
		PostQueuedCompletionStatus(m_hCompletionPort, 0, 0, nullptr);
	}

	m_workerExecutor.Join();

	if (nullptr != m_hCompletionPort)
	{
		CloseHandle(m_hCompletionPort);

		m_hCompletionPort = nullptr;
	}

	ClearSessions();

	return;
}

void jh::IocpServer::ClearSessions()
{
	// �������� ���� ���ǵ��� ����
	for (int i = 0; i < m_config.m_dwMaxSessionCnt; i++)
	{
		Session* sessionPtr = &m_pSessionArray[i];

		if (INVALID_SOCKET == sessionPtr->m_socket)
			continue;

		LONGLONG sessionIdx = sessionPtr->m_ullSessionId >> SESSION_IDX_SHIFT_BIT;

		closesocket(sessionPtr->m_socket);
		sessionPtr->Clear();

		m_sessionIndexStack.Push(sessionIdx);

		InterlockedDecrement(&m_lSessionCount);
	}
}


void jh::IocpServer::InitializeServerTasks()
{
	m_workerExecutor.Run([this]()
		{
			ProcessAccept();
		});

	int creationCount = m_config.m_dwConcurrentWorkerThreadCount * 1.5;
	
	if (ServerType == SERVERTYPE::SINGLE)
	{
		m_workerExecutor.Run([this]()
			{

			});
		for (int i = 0; i < creationCount; i++)
		{
			m_workerExecutor.Run([this]()
				{
					bool isRunning = true;

					while (isRunning)
					{
						isRunning = ProcessIO(10);
					}
				});
		}
	}
	else
	{
		for (int i = 0; i < creationCount; i++)
		{
			m_workerExecutor.Run([this]()
				{
					bool isRunning = true;

					while (isRunning)
					{
						g_tlsEndTickCount = jh_utility::GetTimeStamp() + m_config.m_ullWorkerTick;

						isRunning = ProcessIO(10);

						OnWorkerThreadUpdate();
					}
				});
		}
		m_pJobQueue->DoTimer(m_config.m_ullTimeoutCheckInterval, [this]() {this->OnHeartbeatTimer(); });
	}

	return;
}

void jh::IocpServer::DeleteSession(ULONGLONG sessionId)
{
	if (sessionId == INVALID_SESSION_ID)
	{
		_LOG(m_pcwszServerName, LOG_LEVEL_WARNING, L"[DeleteSession] TryAcquireSession Failed");
		return;
	}

	LONGLONG sessionIdx = sessionId >> SESSION_IDX_SHIFT_BIT;

	Session* sessionPtr = &m_pSessionArray[sessionIdx];
	// ������ �׳� ���� ���� �� ���� �� ������ �����Ǿ��� �� �ִ�. �׷��� ID Ȯ�� �� �ǳ��ֵ��� �Ѵ�.
	if (sessionId != sessionPtr->m_ullSessionId)
	{
		_LOG(L"Session", LOG_LEVEL_DEBUG, L"[DeleteSession] Session ID != _SessionArray[SessionIdx].SessionID, SessionID : [0x%016llx], SessionIdx : [0x%016llx], called by [%s]", sessionId, sessionIdx, PROF_WFUNC);

		return;
	}

	if (InterlockedCompareExchange(&sessionPtr->m_lIoCount, SESSION_DELETE_FLAG, 0) != 0)
	{
		_LOG(m_pcwszServerName, LOG_LEVEL_INFO, L" [DeleteSession] Session is Using. SessionId : [0x%016llx]", sessionPtr->m_ullSessionId);
		return;
	}

	OnDisconnected(sessionPtr->m_ullSessionId);

	closesocket(sessionPtr->m_socket);

	m_activeSessionManager.RemoveActiveSession(sessionPtr->m_ullSessionId);

	sessionPtr->Clear();

	m_sessionIndexStack.Push(sessionIdx);

	InterlockedIncrement64(&m_llTotalDisconnectCount);

	InterlockedDecrement(&m_lSessionCount);

	_LOG(L"Session", LOG_LEVEL_DEBUG, L"[DeleteSessIon] PushStack - SessionID : [0x%016llx], SessionIdx : [0x%016llx]", sessionId, sessionIdx);

	return;
}

void jh::IocpServer::DecreaseIoCount(Session* sessionPtr)
{
	LONG ioCount = InterlockedDecrement(&sessionPtr->m_lIoCount);

	if (0 == ioCount)
		DeleteSession(sessionPtr->m_ullSessionId);
}


void jh::IocpServer::LoadConfig(const ServerConfig& baseServerConfig)
{
	m_config = baseServerConfig;
}

bool jh::IocpServer::InitSessionArray(DWORD maxSessionCount)
{
	if (m_pSessionArray != nullptr)
		return false;

	m_config.m_dwMaxSessionCnt = maxSessionCount;
	m_pSessionArray = new Session[maxSessionCount];

	m_sessionIndexStack.Reserve(maxSessionCount);

	for (int i = 0; i < maxSessionCount; i++)
	{
		m_sessionIndexStack.Push(i);
	}

	return true;
}


void jh::IocpServer::OnHeartbeatTimer()
{
	CheckHeartbeatTimeout();

	m_pJobQueue->DoTimer(m_config.m_ullTimeoutCheckInterval, [this]() {this->OnHeartbeatTimer(); });
}

void jh::IocpServer::SendRequest(Session* sessionPtr, PacketBufferRef& packet)
{
	// �߰��� ����Ǿ����� ������ �� �� �ֱ⶧���� ������ �������� �ʰ� �����ۤ���.
	InterlockedIncrement(&sessionPtr->m_lIoCount);

	bool ret = PostQueuedCompletionStatus(m_hCompletionPort, 1, (ULONG_PTR)sessionPtr, SEND_REQUEST);

	if (false == ret)
		DecreaseIoCount(sessionPtr);
}

jh::Session* jh::IocpServer::TryAcquireSession(ULONGLONG sessionId, const WCHAR* caller)
{
	if (sessionId == INVALID_SESSION_ID)
	{
		_LOG(L"Session", LOG_LEVEL_WARNING, L"[TryAcquireSession] Invalid Session ID [0x%016llx], Caller : [%s]", sessionId, caller);
		return nullptr;
	}

	LONGLONG sessionIdx = sessionId >> SESSION_IDX_SHIFT_BIT;

	Session* sessionPtr = &m_pSessionArray[sessionIdx];
	// ������ �׳� ���� ���� �� ���� �� ������ �����Ǿ��� �� �ִ�. �׷��� ID Ȯ�� �� �ǳ��ֵ��� �Ѵ�.
	if (sessionId != sessionPtr->m_ullSessionId)
	{
		// �̹� ������ ���ǿ� �����ϴ� ���� ���� �������� ����.	
		_LOG(L"Session", LOG_LEVEL_DEBUG, L"[TryAcquireSession] Session ID != _SessionArray[SessionIdx].SessionID, SessionID : [0x%016llx], SessionIdx : [0x%016llx], Caller : [%s]", sessionId, sessionIdx, caller);

		return nullptr;
	}

	if (InterlockedAnd8(&sessionPtr->m_bConnectedFlag, 1) == 0)
	{
		return nullptr;
	}

	// ���� �Ŀ���. ���� ���ǿ� ���ؼ� ����ϱ� ���� �� �༮�� �������ΰ� �ƴѰ��� Ȯ���ϴ� ������ �ʿ��ϴ�.
	if (0 != (SESSION_DELETE_FLAG & InterlockedIncrement(&sessionPtr->m_lIoCount)))
	{
		DecreaseIoCount(sessionPtr);

		return nullptr;
	}

	return sessionPtr;
}

bool jh::IocpServer::ProcessIO(DWORD timeout)
{
	LPOVERLAPPED lpOverlapped = nullptr;
	DWORD transferredBytes = 0;
	ULONG_PTR key = 0;

	Session* sessionPtr = nullptr;

	bool gqcsRet = GetQueuedCompletionStatus(m_hCompletionPort, &transferredBytes,
		reinterpret_cast<PULONG_PTR>(&sessionPtr), &lpOverlapped, timeout);

	if (nullptr == lpOverlapped)
	{
		// gqcsRet == true -> pqcs�� ���� lpOverlapped �� nullptr
		// gqcsRet == false -> completionPort�� closeHandle�� ���� �Ǵ� timeout.
		if (false == gqcsRet)
		{
			int gle = WSAGetLastError();

			if (WAIT_TIMEOUT == gle)
				return true;

			_LOG(m_pcwszServerName, LOG_LEVEL_INFO, L"[WorkerThreadMain] ProcessIO - Close Completion port [WSAGetLastError : %d]", gle);
		}
		return false;
	}

	if (transferredBytes != 0)
	{
		if (&sessionPtr->m_recvOverlapped == lpOverlapped)
		{
			ProcessRecv(sessionPtr, transferredBytes);
		}
		else if (&sessionPtr->m_sendOverlapped == lpOverlapped)
		{
			ProcessSend(sessionPtr, transferredBytes);
		}
		else if (SEND_REQUEST == lpOverlapped)
		{
			PostSend(sessionPtr);
		}
	}
	else
	{
		if (&sessionPtr->m_sendOverlapped == lpOverlapped)
			_LOG(m_pcwszServerName, LOG_LEVEL_INFO, L"[WorkerThreadMain] ProcessIO - SND :  SessionID: [0x%016llx]", sessionPtr->m_ullSessionId);
	}

	DecreaseIoCount(sessionPtr);

	return true;
}

bool jh::IocpServer::OnConnectionRequest(const SOCKADDR_IN& clientInfo)
{
	return true;
}


void jh::IocpServer::OnError(int errCode, WCHAR* cause)
{
}

void jh::IocpServer::OnWorkerThreadUpdate()
{
}

void jh::IocpServer::ProcessRecv(Session* sessionPtr, DWORD transferredBytes)
{
	if (false == sessionPtr->m_recvBuffer.MoveRear(transferredBytes))
	{
		Disconnect(sessionPtr->m_ullSessionId, L"ProcessRecv - Recv Buffer Overflow");

		return;
	}

	while (1)
	{
		int bufferSize = sessionPtr->m_recvBuffer.GetUseSize();

		// packetheader���� ���� ����

#ifdef  ECHO
		USHORT header;

		if (bufferSize < sizeof(header))
			break;

		sessionPtr->m_recvBuffer.PeekRetBool(reinterpret_cast<char*>(&header), sizeof(header));

		if (bufferSize < (sizeof(header) + header))
			break;

		sessionPtr->m_recvBuffer.MoveFront(sizeof(header));

		PacketBufferRef packet = jh::MakeShared<PacketBuffer>(header);

		if (false == sessionPtr->m_recvBuffer.DequeueRetBool(packet->GetRearPtr(), header))
		{
			Disconnect(sessionPtr->m_ullSessionId, L"ProcessRecv - Recv Buffer Deque Failed");

			return;
		}

		packet->MoveRearPos(header);

		OnRecv(sessionPtr->m_ullSessionId, packet, 0);

#else
		if (bufferSize < sizeof(PacketHeader))
			break;

		PacketHeader header;

		sessionPtr->m_recvBuffer.PeekRetBool(reinterpret_cast<char*>(&header), sizeof(PacketHeader));

		if (bufferSize < (sizeof(PacketHeader) + header.size))
			break;

		sessionPtr->m_recvBuffer.MoveFront(sizeof(header));

		PacketBufferRef packet = jh::MakeShared<PacketBuffer>(header.size);

		if (false == sessionPtr->m_recvBuffer.DequeueRetBool(packet->GetRearPtr(), header.size))
		{
			Disconnect(sessionPtr->m_ullSessionId, L"ProcessRecv - Recv Buffer Deque Failed");

			return;
		}

		packet->MoveRearPos(header.size);

		OnRecv(sessionPtr->m_ullSessionId, packet, header.type);
#endif
		InterlockedIncrement(&m_lRecvCount);
	}

	PostRecv(sessionPtr);

	return;
}

void jh::IocpServer::ProcessSend(Session* sessionPtr, DWORD transferredBytes)
{
	size_t pendingCnt = sessionPtr->m_sendOverlapped.m_pendingList.size();

	InterlockedAdd(&m_lSendCount, pendingCnt);

	sessionPtr->m_sendOverlapped.ClearPendingList();

	InterlockedExchange8(&sessionPtr->m_bSendFlag, 0);

	// send �Ϸ������� sendPacket���� ������ ���� �ذ��� ���� ������ üũ�� �߰�.
#ifdef USE_SESSION_LOG
	if (sessionPtr->m_sendQ.GetUseSize() > 0)
		PostSend(sessionPtr, PROCESS_SEND);
#else
	if (sessionPtr->m_sendQ.GetUseSize() > 0)
		PostSend(sessionPtr);
#endif
	return;
}

void jh::IocpServer::Disconnect(ULONGLONG sessionId, const WCHAR* reason)
{
	Session* sessionPtr = TryAcquireSession(sessionId, PROF_WFUNC);

	if (nullptr == sessionPtr)
		return;

	_LOG(m_pcwszServerName, LOG_LEVEL_INFO, L"Disconnect Reason : [%s]", reason);

	// ���� ���� ���°� �ƴ�, ���� ������ ���� ��Ȳ����
	// ��� �Ϸ� ������ ������ �� Disconnect()�� ȣ��ȴٸ�
	// �״��� �Ϸ� ������ ó���� �� i/o ����� ���´�.
	InterlockedExchange8(&sessionPtr->m_bConnectedFlag, 0);

	// recv, send�� ��ϵǾ��ٸ� �� �� io ����Ѵ�.
	CancelIoEx(reinterpret_cast<HANDLE>(sessionPtr->m_socket), nullptr);

	DecreaseIoCount(sessionPtr);
}

#ifdef USE_SESSION_LOG
void jh::IocpServer::PostSend(Session* sessionPtr, DWORD entry)
{
	DWORD entryOrder = sessionPtr->m_pSessionLogger->GetSnapShot();

	if (InterlockedAnd8(&sessionPtr->m_bConnectedFlag, 1) == 0)
	{
		sessionPtr->m_pSessionLogger->Log(entry, CONNECTED_FALSE, entryOrder);
		return;
	}
	if (InterlockedExchange8(&sessionPtr->m_bSendFlag, 1) == 1)
	{
		sessionPtr->m_pSessionLogger->Log(entry, SEND_FLAG_1, entryOrder);
		return;
	}

	// �տ��� ���� �͸����δ� ��� ���� �� ����.
	// 0���� �ƴ��� Ȯ���ϰ� ������ ������ 0���� �� �� ����.
	if (sessionPtr->m_sendQ.GetUseSize() == 0)
	{
		sessionPtr->m_pSessionLogger->Log(entry, USE_SIZE_0, entryOrder);

		InterlockedExchange8(&sessionPtr->m_bSendFlag, 0);
		return;
	}

	static thread_local alignas(64) std::queue<PacketBufferRef> tempQ;

	sessionPtr->m_sendQ.Swap(tempQ);

	int popCount = tempQ.size();

	while (tempQ.size() > 0)
	{
		sessionPtr->m_sendOverlapped.m_pendingList.push_back(std::move(tempQ.front()));

		tempQ.pop();
	}

	std::vector<WSABUF> wsaBufs;

	wsaBufs.reserve(popCount);

	for (PacketBufferRef& packet : sessionPtr->m_sendOverlapped.m_pendingList)
	{
		wsaBufs.push_back({ static_cast<ULONG>(packet->GetDataSize()), packet->GetFrontPtr() });
	}

	InterlockedIncrement(&sessionPtr->m_lIoCount);

	int sendRet = WSASend(sessionPtr->m_socket, wsaBufs.data(), popCount, nullptr, 0, reinterpret_cast<LPWSAOVERLAPPED>(&sessionPtr->m_sendOverlapped), nullptr);

	if (sendRet == SOCKET_ERROR)
	{
		int gle = WSAGetLastError();

		// ��Ͽ� ������ ��Ȳ
		if (gle != WSA_IO_PENDING)
		{
			switch (gle)
			{

				// ����ڰ� �Ϲ������� ������ ���� ���� ���� ����� ���� �ʵ��� �ϰڴ�.  WSAECONNRESET
			case 10054:break;
			case 10053:
			default:
				_LOG(m_pcwszServerName, LOG_LEVEL_WARNING, L" [PostSend] WSASend failed. WSAGetLastError: [%d], SessionID: [0x%016llx]", gle, sessionPtr->m_ullSessionId);
				break;
			}

			DecreaseIoCount(sessionPtr);

			return;
		}
	}
}

#endif
void jh::IocpServer::PostSend(Session* sessionPtr)
{
	if (InterlockedAnd8(&sessionPtr->m_bConnectedFlag, 1) == 0)
		return;

	if (InterlockedExchange8(&sessionPtr->m_bSendFlag, 1) == 1)
		return;

	// �տ��� ���� �͸����δ� ��� ���� �� ����.
	// 0���� �ƴ��� Ȯ���ϰ� ������ ������ 0���� �� �� ����.
	if (sessionPtr->m_sendQ.GetUseSize() == 0)
	{
		InterlockedExchange8(&sessionPtr->m_bSendFlag, 0);
		return;
	}

	static thread_local alignas(64) std::queue<PacketBufferRef> tempQ;

	sessionPtr->m_sendQ.Swap(tempQ);

	int popCount = tempQ.size();

	while (tempQ.size() > 0)
	{
		sessionPtr->m_sendOverlapped.m_pendingList.push_back(std::move(tempQ.front()));

		tempQ.pop();
	}

	std::vector<WSABUF> wsaBufs;

	wsaBufs.reserve(popCount);

	for (PacketBufferRef& packet : sessionPtr->m_sendOverlapped.m_pendingList)
	{
		wsaBufs.push_back({ static_cast<ULONG>(packet->GetDataSize()), packet->GetFrontPtr() });
	}

	InterlockedIncrement(&sessionPtr->m_lIoCount);

	int sendRet = WSASend(sessionPtr->m_socket, wsaBufs.data(), popCount, nullptr, 0, reinterpret_cast<LPWSAOVERLAPPED>(&sessionPtr->m_sendOverlapped), nullptr);

	if (sendRet == SOCKET_ERROR)
	{
		int gle = WSAGetLastError();

		// ��Ͽ� ������ ��Ȳ
		if (gle != WSA_IO_PENDING)
		{
			switch (gle)
			{

				// ����ڰ� �Ϲ������� ������ ���� ���� ���� ����� ���� �ʵ��� �ϰڴ�.  WSAECONNRESET
			case 10054:break;
			case 10053:
			default:
				_LOG(m_pcwszServerName, LOG_LEVEL_WARNING, L" [PostSend] WSASend failed. WSAGetLastError: [%d], SessionID: [0x%016llx]", gle, sessionPtr->m_ullSessionId);
				break;
			}

			DecreaseIoCount(sessionPtr);

			return;
		}
	}
}

void jh::IocpServer::PostRecv(Session* sessionPtr)
{
	if (InterlockedAnd8(&sessionPtr->m_bConnectedFlag, 1) == 0)
		return;

	WSABUF buf[2]{};

	int directEnqueueSize = sessionPtr->m_recvBuffer.DirectEnqueueSize();
	int remainderSize = sessionPtr->m_recvBuffer.GetFreeSize() - directEnqueueSize;
	DWORD wsabufSize = 1;

	buf[0].buf = sessionPtr->m_recvBuffer.GetRearBufferPtr();
	buf[0].len = directEnqueueSize;

	if (remainderSize > 0)
	{
		++wsabufSize;
		buf[1].buf = sessionPtr->m_recvBuffer.GetStartBufferPtr();
		buf[1].len = remainderSize;
	}

	DWORD flag = 0;

	InterlockedIncrement(&sessionPtr->m_lIoCount);

	int recvRet = WSARecv(sessionPtr->m_socket, buf, wsabufSize, nullptr, &flag, reinterpret_cast<LPWSAOVERLAPPED>(&sessionPtr->m_recvOverlapped), nullptr);

	if (recvRet == SOCKET_ERROR)
	{
		int gle = WSAGetLastError();

		if (gle != WSA_IO_PENDING)
		{
			switch (gle)
			{
				// ����ڰ� �Ϲ������� ������ ���� ���� ���� ����� ���� �ʵ��� �ϰڴ�. WSAECONNRESET
			case 10054:break;
			case 10053:
			default:
				_LOG(m_pcwszServerName, LOG_LEVEL_WARNING, L"[PostRecv] WSARecv failed. WSAGetLastError: [%d], SessionID: [0x%016llx]", gle, sessionPtr->m_ullSessionId);
				Disconnect(sessionPtr->m_ullSessionId, L"rcv");
				break;
			}

			DecreaseIoCount(sessionPtr);

			return;
		}
	}
}


void jh::IocpServer::UpdateHeartbeat(ULONGLONG sessionId, ULONGLONG timeStamp)
{
	Session* sessionPtr = TryAcquireSession(sessionId, PROF_WFUNC);

	if (nullptr == sessionPtr)
	{
		_LOG(m_pcwszServerName, LOG_LEVEL_WARNING, L"[UpdateHeartbeat] TryAcquireSession Failed, 0x%016llx", sessionId);
		return;
	}
	if (timeStamp > sessionPtr->m_ullLastTimeStamp)
		sessionPtr->m_ullLastTimeStamp = timeStamp;

	DecreaseIoCount(sessionPtr);

}

void jh::IocpServer::CheckHeartbeatTimeout()
{
	ULONGLONG now = jh_utility::GetTimeStamp();
	std::vector<ULONGLONG> sessions = m_activeSessionManager.GetSessionSnapshot();

	ULONGLONG timeoutLimit = m_config.m_ullTimeoutLimit;
	for (ULONGLONG sessionId : sessions)
	{
		Session* sessionPtr = TryAcquireSession(sessionId, PROF_WFUNC);

		if (nullptr == sessionPtr)
		{
			_LOG(m_pcwszServerName, LOG_LEVEL_WARNING, L"[CheckHeartbeatTimeout] TryAcquireSession Failed, %0x", sessionId);
			return;
		}

		if (now - sessionPtr->m_ullLastTimeStamp > timeoutLimit)
		{
			Disconnect(sessionId, L"Heartbeat");
		}
		DecreaseIoCount(sessionPtr);
	}
}
//static alignas(64) std::vector<ULONGLONG> disconnList;

//auto func = [this, now](ULONGLONG sessionId) {
//	Session* sessionPtr = TryAcquireSession(sessionId, PROF_WFUNC);

//	if (nullptr == sessionPtr)
//	{
//		_LOG(m_pcwszServerName, LOG_LEVEL_WARNING, L"[CheckHeartbeatTimeout] TryAcquireSession Failed, %0x", sessionId);
//		return;
//	}

//	if (now - sessionPtr->m_ullLastTimeStamp > m_ullTimeoutLimit)
//	{
//		disconnList.push_back(sessionId);
//	}
//	DecreaseIoCount(sessionPtr);
//};

//m_activeSessionManager.ProcessAllSessions(func);

//for (ULONGLONG sessionId : disconnList)
//{
//	Disconnect(sessionId, L"Heartbeat");
//}
//
//disconnList.clear();
//}

// 0�� ���ϵǴ� ���� �߸��� ����̴�.
USHORT jh::IocpServer::GetPort() const
{
	if (0 != m_config.m_usPort && INVALID_SOCKET != m_listenSock)
		return m_config.m_usPort;

	return jh::NetAddress::GetPort(m_listenSock);
}

void jh::IocpServer::SendPacket(ULONGLONG sessionId, PacketBufferRef& packet)
{
	Session* sessionPtr = TryAcquireSession(sessionId, PROF_WFUNC);

	if (nullptr == sessionPtr)
	{
		return;
	}

	sessionPtr->m_sendQ.Push(packet);

	SendRequest(sessionPtr, packet);
//
//#ifdef  USE_SESSION_LOG
//	PostSend(sessionPtr, SEND_PACKET);
//#else
	//PostSend(sessionPtr);
	//#endif //  USE_SESSION_LOG

	DecreaseIoCount(sessionPtr);
}



void jh::IocpServer::ProcessAccept()
{
	while (1)
	{
		SOCKADDR_IN clientInfo{};
		int infoSize = sizeof(clientInfo);
		SOCKET clientSock = accept(m_listenSock, (SOCKADDR*)&clientInfo, &infoSize);

		// Accept ����
		if (clientSock == INVALID_SOCKET)
		{
			DWORD lastErr = WSAGetLastError();
			_LOG(m_pcwszServerName, LOG_LEVEL_WARNING, L"[ProcessAccept] Client Socket is invalid.");
			break;
		}
		if (!OnConnectionRequest(clientInfo)) // Client�� ������ ������ �� ���� ������ ���� ��
		{
			closesocket(clientSock);
			continue;
		}

		Session* newSession = CreateSession(clientSock, &clientInfo);

		if (nullptr == newSession)
		{
			_LOG(m_pcwszServerName, LOG_LEVEL_WARNING, L"[ProcessAccept] newSession is nullptr.");

			closesocket(clientSock);
			continue;
		}

		OnConnected(newSession->m_ullSessionId);

		PostRecv(newSession);

		// �����ǰ� �����ؾ��ϴ� �۾��� ������ ioCount�� 0�̶�� send �� �ٷ� ó���Ǿ ����Ǵ� ��찡 ����
		// �׷��� ������ Create�Ҷ� ioCount�� 1�� �����ϰ� �۾� �Ŀ� ���ҽ�Ų��.
		DecreaseIoCount(newSession);
	}
}

jh::Session* jh::IocpServer::CreateSession(SOCKET sock, const SOCKADDR_IN* pSockAddr)
{
	DWORD availableIndex = UINT_MAX;

	if (false == m_sessionIndexStack.TryPop(availableIndex))
	{
		_LOG(m_pcwszServerName, LOG_LEVEL_INFO, L"[CreateSession] Session pool is empty, SessionCount : [%u].", m_lSessionCount);

		return nullptr;
	}

	// ���� ���� ������Ű��.
	Session* sessionPtr = &m_pSessionArray[availableIndex];

	static ULONG sessionIdGen = 0;

	// Session�� ����� id
	// [16 idx ][48 id]
	ULONGLONG id = (static_cast<ULONGLONG>(availableIndex) << SESSION_IDX_SHIFT_BIT) | ((++sessionIdGen) & SESSION_ID_MASKING_BIT);

	// ���� �ʱ�ȭ
	bool activateRet = sessionPtr->Activate(sock, pSockAddr, id);

	if (false == activateRet)
	{
		closesocket(sock);

		sessionPtr->Clear();

		m_sessionIndexStack.Push(availableIndex);

		_LOG(m_pcwszServerName, LOG_LEVEL_WARNING, L"[CreateSession] Activate failed");

		return nullptr;
	}

	_LOG(L"Session", LOG_LEVEL_DEBUG, L"[CreateSession] Session Index : 0x%016llx, Session ID : 0x%016llx ", availableIndex, id);

	m_activeSessionManager.AddActiveSession(sessionPtr);
	// ���� ��� ����
	HANDLE registerRet = CreateIoCompletionPort(reinterpret_cast<HANDLE>(sock), m_hCompletionPort, reinterpret_cast<ULONG_PTR>(sessionPtr), 0);

	if (nullptr == registerRet)
	{
		closesocket(sock);

		sessionPtr->Clear();

		m_sessionIndexStack.Push(availableIndex);

		_LOG(m_pcwszServerName, LOG_LEVEL_WARNING, L"[CreateSession] CreateIoCompletionPort() failed");

		return nullptr;
	}

	InterlockedIncrement(&m_lSessionCount);

	InterlockedIncrement64(&m_llTotalAcceptedSessionCount);

	return sessionPtr;
}